import React, { Component } from 'react';
import CheckOutSummary from '../../components/Order/CheckOutSummary/CheckOutSummary';
import ContactData from './ContactData/ContactData';
import {Route} from 'react-router-dom';

 class CheckOut extends Component {
     state={
        ingredient:null,
        burgerPrice:0
     }
     componentWillMount(){
         this.getIngredientsFromQueryParams();
     }
     getIngredientsFromQueryParams=()=>{
        const query=new URLSearchParams(this.props.location.search);
        const ingredient={};
        let burgerPrice=0;
        for(let param of query.entries()){
            if(param[0]=== 'price'){
                burgerPrice=param[1];
            }else{
                ingredient[param[0]]=+param[1];
            }
        }
        this.setState({ingredient,burgerPrice:burgerPrice});
     }
     checkOutCancelHandler=()=>{
         this.props.history.goBack();
     }
     checkOutContinueHandler=(event)=>{
         event.preventDefault();
        this.props.history.replace(this.props.match.path + '/contact-data');
     }
    render() {
        return (
            <div>
                <CheckOutSummary
                    ingredient={this.state.ingredient}
                    checkOutCancel={this.checkOutCancelHandler}
                    checkOutContinue={this.checkOutContinueHandler}
                 />
                <Route 
                    path={this.props.match.path + '/contact-data'} 
                    render={(props)=>(<ContactData ingredient={this.state.ingredient} price={this.state.burgerPrice} {...props}/>)}
                />
                </div>
        )
    }
}

export default CheckOut

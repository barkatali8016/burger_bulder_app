import React, { Component } from 'react';
import Burger from '../../components/Burger/Burger';
import BuildControls from '../../components/Burger/BuildControls/BuildControls';
import Modal from '../../components/UI/Modal/Modal';
import OrderSummary from '../../components/Burger/OrderSummary/OrderSummary';
import axios from '../../axiosOrder';
import Spinner from '../../components/UI/Spinner/Spinner';
import withErrorHandler from '../../hoc/withErrorHandler/withErrorHandler';

const INGREDIENT_PRICE = {
    salad: 0.5,
    bacon: 0.4,
    cheese: 1.3,
    meat: 0.7
}
class BurgerBulder extends Component {
    state = {
        ingredient: null,
        burgerPrice: 4,
        purchasable: false,
        purchasing: false,
        loading: false,
        error:false
    }
    componentDidMount() {
        this.getIngredient()
    }
    getIngredient = () => {
        axios.get('/indredient.json')
            .then(response => {
                console.log(response);
                this.setState({ ingredient: response.data });
            })
            .catch(err => {
                this.setState({error:true})
            });
    }
    purchasableHandle = (ingredient) => {

        let sum = Object.keys(ingredient).map(keys => {
            return ingredient[keys];
        }).reduce((sum, el) => {
            return sum + el;
        }, 0)
        this.setState({ purchasable: sum > 0 })
    }
    addIngredientHandler = (type) => {
        let oldCount = this.state.ingredient[type];
        let newCount = oldCount + 1;
        let updatedIngredient = { ...this.state.ingredient };
        updatedIngredient[type] = newCount;
        let priceAddition = INGREDIENT_PRICE[type];
        let oldPrice = this.state.burgerPrice;
        let newPrice = oldPrice + priceAddition;
        this.setState({ ingredient: updatedIngredient, burgerPrice: newPrice });
        this.purchasableHandle(updatedIngredient);
    }
    removeIngredientHandler = (type) => {
        let oldCount = this.state.ingredient[type];
        if (oldCount <= 0) {
            return;
        }
        let newCount = oldCount - 1;
        let updatedIngredient = { ...this.state.ingredient };
        updatedIngredient[type] = newCount;
        let priceDeduction = INGREDIENT_PRICE[type];
        let oldPrice = this.state.burgerPrice;
        let newPrice = oldPrice - priceDeduction;
        this.setState({ ingredient: updatedIngredient, burgerPrice: newPrice });
        this.purchasableHandle(updatedIngredient);
    }
    showModal = () => {

        this.setState({ purchasing: true }, () => {
            console.log(this.state.purchasing)
        });
    }

    purchaseCancelHandle = () => {

        this.setState({ purchasing: false }, () => {
            console.log(this.state.purchasing);
        });
    }
    purchaseContinueHandle = () => {
        const queryParam=[];
        for(let i in this.state.ingredient){
            queryParam.push(encodeURIComponent(i)+'='+encodeURIComponent(this.state.ingredient[i]))
        }
        queryParam.push('price='+this.state.burgerPrice);
        const queryString=queryParam.join('&');

        this.props.history.push({
            pathname:'/checkout',
            search:'?' +queryString
        });
    }
    orderSubmited=()=>{
        this.setState({isOrder:false})
    }
    render() {
        let orderSumary = <Spinner />
        let burger = this.state.error?<p style={{textAlign:'center'}}>Ingredient can't be load</p>:<Spinner />
        if (this.state.ingredient) {
            let disabledInfo = { ...this.state.ingredient }
            for (let key in disabledInfo) {
                disabledInfo[key] = disabledInfo[key] <= 0
            }
            burger = (<React.Fragment>
                <Burger ingredient={this.state.ingredient} />
                <BuildControls
                    priceAdded={this.addIngredientHandler}
                    priceRemoved={this.removeIngredientHandler}
                    disabledInfo={disabledInfo}
                    burgerPrice={this.state.burgerPrice}
                    purchasable={this.state.purchasable}
                    showModalHandle={this.showModal}
                />
            </React.Fragment>)
            orderSumary = <OrderSummary
                ingredient={this.state.ingredient}
                purchaseContinue={this.purchaseContinueHandle}
                purchaseCancel={this.purchaseCancelHandle}
                burgerPrice={this.state.burgerPrice}
            />;
            if (this.state.loading) {
                orderSumary = <Spinner />
            }
        }
        return (<React.Fragment>
            <Modal purchasing={this.state.purchasing} modalClosed={this.purchaseCancelHandle}>
                {orderSumary}
            </Modal>
            {burger}
        </React.Fragment>)
    }
}

export default withErrorHandler(BurgerBulder, axios);
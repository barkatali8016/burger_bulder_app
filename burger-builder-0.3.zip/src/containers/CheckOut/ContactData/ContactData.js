import React, { Component } from 'react';
import Button from '../../../components/UI/Button/Button';
import classes from './ContactData.module.css';
import axios from '../../../axiosOrder';
import Spinner from "../../../components/UI/Spinner/Spinner";

class ContactData extends Component {
    state = {
        name: '',
        email: '',
        address: {
            street: '',
            postalCode: ''
        },
        loading: false
    }
    orderHandler = (e) => {
        e.preventDefault();
        console.log(this.props);

        this.setState({ loading: true })
        const order = {
            ingredient: this.props.ingredient,
            price: this.props.price,
            customer: {
                name: 'Barkat Ali',
                address: {
                    street: 'naya patti',
                    zipCode: '700021',
                    country: 'India'
                },
                email: 'barkat@gmail.com'
            },
            deliveryMethod: 'fastest'
        }

        //making http request to firebase 
        axios.post('/orders.json', order)
            .then(response => {
                console.log(response)
                this.setState({ loading: false })
                this.props.history.push('/');
            })
            .catch(error => {
                this.setState({ loading: false })
            });
    }
    render() {
        return (
            <div className={classes.ContactData}>
                <h4>Enter Your Contact Data</h4>
                {
                    this.state.loading ? <Spinner />
                        : <form>
                            <input className={classes.Input} type='text' placeholder='Enter Your Name' />
                            <input className={classes.Input} type='email' placeholder='Enter Your Email' />
                            <input className={classes.Input} type='text' placeholder='Enter Your Street' />
                            <input className={classes.Input} type='text' placeholder='Enter Your Postal Code' />
                            <Button btnType="Success" clicked={this.orderHandler}>Order</Button>
                        </form>
                }

            </div>
        )
    }
}

export default ContactData

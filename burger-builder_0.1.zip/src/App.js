import React from 'react';
import Layout from './components/Layout/Layout';
import BurgerBulder from './containers/BurgerBuilder/BurgerBuilder'; 
import classes from './components/Layout/Layout.module.css'
function App() {
  console.log(classes)
  return (
    <div >
     <Layout>
       <BurgerBulder />
       <p className={classes.bgColor}>pppppppppppppp</p>
     </Layout>
    </div>
  );
}

export default App;

import React from 'react';
import './Layout.module.css'
const layout=(props)=>{
    return(
        <React.Fragment>
            <div>Toolbar ,SideDrawer, backdrop</div>
            <main className='Content'>
                {props.children}
            </main>
        </React.Fragment>
    )
}

export default layout;
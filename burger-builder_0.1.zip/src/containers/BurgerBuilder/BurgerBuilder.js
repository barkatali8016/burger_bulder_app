import React,{Component} from 'react';
import Burger from '../../components/Burger/Burger'
class BurgerBulder extends Component{
    render(){
        return(<React.Fragment>
            <Burger/>
            <div>Burger Control</div>
        </React.Fragment>)
    }
}

export default BurgerBulder;